package com.releaseguard.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.releaseguard.entity.Change;
import com.releaseguard.entity.MlPredictionEntity;
import com.releaseguard.ml.dto.MlPredictionResponse;
import com.releaseguard.repository.MlPredictionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MlPredictionPersistenceService {

    private final MlPredictionRepository repository;
    private final ObjectMapper objectMapper;

    public MlPredictionPersistenceService(
        MlPredictionRepository repository,
        ObjectMapper objectMapper
    ) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public MlPredictionEntity save(
        Change change,
        MlPredictionResponse prediction
    ) {
        MlPredictionEntity entity =
            repository.findByChangeId(change.getId())
                .orElseGet(MlPredictionEntity::new);

        entity.setChange(change);

        entity.setRiskLevel(
            prediction.getRiskLevel()
        );

        entity.setRiskScore(
            prediction.getRiskScore()
        );

        entity.setClassProbabilities(
            writeJson(prediction.getClassProbabilities())
        );

        entity.setFeatureVector(
            writeJson(prediction.getFeatureVector())
        );

        entity.setModelName(
            prediction.getModelName()
        );

        entity.setModelVersion(
            prediction.getModelVersion()
        );

        entity.setFeatureVersion(
            prediction.getFeatureVersion()
        );

        entity.setDatasetVersion(
            prediction.getDatasetVersion()
        );

        return repository.save(entity);
    }

    @Transactional(readOnly = true)
    public MlPredictionEntity getByChangeId(Long changeId) {
        return repository
            .findByChangeId(changeId)
            .orElse(null);
    }

    private String writeJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException(
                "Failed to serialize ML prediction payload",
                exception
            );
        }
    }
}
