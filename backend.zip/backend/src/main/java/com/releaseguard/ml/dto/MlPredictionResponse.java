package com.releaseguard.ml.dto;

import java.util.Map;

public class MlPredictionResponse {

    private String riskLevel;
    private double riskScore;
    private Map<String, Double> classProbabilities;
    private Map<String, Double> featureVector;
    private String modelName;
    private String modelVersion;
    private String featureVersion;
    private String datasetVersion;

    public MlPredictionResponse() {
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public double getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(double riskScore) {
        this.riskScore = riskScore;
    }

    public Map<String, Double> getClassProbabilities() {
        return classProbabilities;
    }

    public void setClassProbabilities(
        Map<String, Double> classProbabilities
    ) {
        this.classProbabilities = classProbabilities;
    }

    public Map<String, Double> getFeatureVector() {
        return featureVector;
    }

    public void setFeatureVector(
        Map<String, Double> featureVector
    ) {
        this.featureVector = featureVector;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public void setModelVersion(String modelVersion) {
        this.modelVersion = modelVersion;
    }

    public String getFeatureVersion() {
        return featureVersion;
    }

    public void setFeatureVersion(String featureVersion) {
        this.featureVersion = featureVersion;
    }

    public String getDatasetVersion() {
        return datasetVersion;
    }

    public void setDatasetVersion(String datasetVersion) {
        this.datasetVersion = datasetVersion;
    }
}
