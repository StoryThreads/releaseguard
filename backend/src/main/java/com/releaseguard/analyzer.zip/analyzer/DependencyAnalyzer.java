package com.releaseguard.analyzer;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DependencyAnalyzer implements Analyzer {

    private static final String RULE_DEPENDENCY_CHANGE = "DEP-001";

    @Override
    public AnalyzerType getType() {
        return AnalyzerType.DEPENDENCY;
    }

    @Override
    public List<Finding> analyze(AnalyzerContext context) {

        List<Finding> findings = new ArrayList<>();

        if (context == null || context.snapshot() == null) {
            return findings;
        }

        ChangeSnapshot snapshot = context.snapshot();

        if (snapshot.getChangedFiles() == null) {
            return findings;
        }

        for (var file : snapshot.getChangedFiles()) {

            if (file == null || file.getFilename() == null) {
                continue;
            }

            String filename = file.getFilename();

            if (!isDependencyFile(filename)) {
                continue;
            }

            String patch = file.getPatch();

            if (patch == null || patch.isBlank()) {
                continue;
            }

            if (containsDependencyChange(patch)) {

                findings.add(new Finding(
                    AnalyzerType.DEPENDENCY,
                    FindingType.DEPENDENCY_ISSUE,
                    FindingSeverity.MEDIUM,
                    RULE_DEPENDENCY_CHANGE,
                    "Dependency change detected",
                    "A dependency change was detected in the pull request.",
                    filename,
                    null
                ));
            }
        }

        return findings;
    }

    private boolean isDependencyFile(String filename) {

        return filename.equals("pom.xml")
            || filename.equals("package.json")
            || filename.equals("build.gradle")
            || filename.equals("build.gradle.kts");
    }

    private boolean containsDependencyChange(String patch) {

        return patch.lines()
            .anyMatch(line ->
                line.startsWith("+")
                    || line.startsWith("-")
            );
    }
}
